-- Veritabanı oluşturma
SHOW DATABASES;
USE restoran_vt;

-- Kullanıcılar tablosu (garson, mutfak personeli vb.)
CREATE TABLE kullanicilar (
    kullanici_id INT PRIMARY KEY AUTO_INCREMENT,
    kullanici_adi VARCHAR(50) NOT NULL UNIQUE,
    sifre VARCHAR(255) NOT NULL,
    ad_soyad VARCHAR(100) NOT NULL,
    rol ENUM('garson', 'mutfak', 'yonetici') NOT NULL,
    aktif BOOLEAN DEFAULT TRUE,
    kayit_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Masalar tablosu
CREATE TABLE masalar (
    masa_id INT PRIMARY KEY AUTO_INCREMENT,
    masa_no VARCHAR(10) NOT NULL UNIQUE,
    kapasite INT NOT NULL,
    durum ENUM('bos', 'dolu', 'rezerve') DEFAULT 'bos',
    konum VARCHAR(50)
);

-- Ürün kategorileri
CREATE TABLE kategoriler (
    kategori_id INT PRIMARY KEY AUTO_INCREMENT,
    kategori_adi VARCHAR(50) NOT NULL UNIQUE,
    aciklama TEXT
);

-- Ürünler tablosu
CREATE TABLE urunler (
    urun_id INT PRIMARY KEY AUTO_INCREMENT,
    urun_adi VARCHAR(100) NOT NULL,
    kategori_id INT NOT NULL,
    fiyat DECIMAL(10,2) NOT NULL,
    stok_durumu BOOLEAN DEFAULT TRUE,
    aciklama TEXT,
    resim_url VARCHAR(255),
    FOREIGN KEY (kategori_id) REFERENCES kategoriler(kategori_id)
);

-- Sipariş durumları
CREATE TABLE siparis_durumlari (
    durum_id INT PRIMARY KEY AUTO_INCREMENT,
    durum_adi VARCHAR(50) NOT NULL UNIQUE,
    aciklama TEXT
);

-- Siparişler tablosu
CREATE TABLE siparisler (
    siparis_id INT PRIMARY KEY AUTO_INCREMENT,
    masa_id INT NOT NULL,
    kullanici_id INT, -- Siparişi alan garson
    durum_id INT NOT NULL,
    toplam_tutar DECIMAL(10,2),
    siparis_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    teslim_tarihi DATETIME,
    notlar TEXT,
    FOREIGN KEY (masa_id) REFERENCES masalar(masa_id),
    FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id),
    FOREIGN KEY (durum_id) REFERENCES siparis_durumlari(durum_id)
);

-- Sipariş detayları tablosu
CREATE TABLE siparis_detaylari (
    detay_id INT PRIMARY KEY AUTO_INCREMENT,
    siparis_id INT NOT NULL,
    urun_id INT NOT NULL,
    adet INT NOT NULL DEFAULT 1,
    birim_fiyat DECIMAL(10,2) NOT NULL,
    notlar TEXT,
    FOREIGN KEY (siparis_id) REFERENCES siparisler(siparis_id) ON DELETE CASCADE,
    FOREIGN KEY (urun_id) REFERENCES urunler(urun_id)
);

-- Sipariş durum geçmişi
CREATE TABLE siparis_gecmisi (
    gecmis_id INT PRIMARY KEY AUTO_INCREMENT,
    siparis_id INT NOT NULL,
    durum_id INT NOT NULL,
    degisim_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    kullanici_id INT, -- Durumu değiştiren kullanıcı
    aciklama TEXT,
    FOREIGN KEY (siparis_id) REFERENCES siparisler(siparis_id),
    FOREIGN KEY (durum_id) REFERENCES siparis_durumlari(durum_id),
    FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id)
);

-- Ödeme bilgileri
CREATE TABLE odemeler (
    odeme_id INT PRIMARY KEY AUTO_INCREMENT,
    siparis_id INT NOT NULL,
    odeme_tarihi DATETIME DEFAULT CURRENT_TIMESTAMP,
    odeme_turu ENUM('nakit', 'kredi_karti', 'diger') NOT NULL,
    tutar DECIMAL(10,2) NOT NULL,
    indirim DECIMAL(10,2) DEFAULT 0,
    kullanici_id INT, -- Ödemeyi alan kullanıcı
    FOREIGN KEY (siparis_id) REFERENCES siparisler(siparis_id),
    FOREIGN KEY (kullanici_id) REFERENCES kullanicilar(kullanici_id)
);

-- Başlangıç verileri ekleme
INSERT INTO siparis_durumlari (durum_adi, aciklama) VALUES
('bekliyor', 'Sipariş alındı, mutfak tarafından işlenmeyi bekliyor'),
('hazirlaniyor', 'Mutfak tarafından hazırlanıyor'),
('hazir', 'Sipariş hazır, garson tarafından teslim edilmeyi bekliyor'),
('teslim-edildi', 'Sipariş müşteriye teslim edildi'),
('iptal-edildi', 'Sipariş iptal edildi');

INSERT INTO kategoriler (kategori_adi, aciklama) VALUES
('Yemekler', 'Ana yemekler'),
('İçecekler', 'Soğuk ve sıcak içecekler'),
('Tatlılar', 'Çeşitli tatlılar'),
('Aperatifler', 'Ara sıcaklar ve mezeler');

-- Örnek ürünler ekleme
INSERT INTO urunler (urun_adi, kategori_id, fiyat, aciklama) VALUES
('Köfte', 1, 85.00, 'El yapımı köfteler'),
('Tavuk Şiş', 1, 75.00, 'Marine edilmiş tavuk şiş'),
('Lahmacun', 1, 30.00, 'İnce hamurlu lahmacun'),
('Pide', 1, 60.00, 'Çeşitli pide seçenekleri'),
('Salata', 1, 45.00, 'Taze mevsim salatası'),
('Ayran', 2, 12.00, 'Ev yapımı ayran'),
('Kola', 2, 15.00, 'Soğuk kola'),
('Şalgam', 2, 14.00, 'Acılı/acişız şalgam'),
('Ice tea', 2, 16.00, 'Soğuk buzlu çay'),
('Sade soda', 2, 10.00, 'Doğal maden sodası'),
('Künefe', 3, 50.00, 'Tepside künefe'),
('Antep baklava', 3, 60.00, 'Gerçek Antep baklavası'),
('San sebastian', 3, 55.00, 'Çikolatalı kek'),
('Sütlaç', 3, 35.00, 'Ev yapımı sütlaç'),
('Kazandibi', 3, 40.00, 'Kremalı kazandibi');

-- Örnek masa ekleme
INSERT INTO masalar (masa_no, kapasite, konum) VALUES
('M1', 4, 'Bahçe'),
('M2', 4, 'Bahçe'),
('M3', 6, 'Salon'),
('M4', 6, 'Salon'),
('M5', 8, 'Salon'),
('M6', 2, 'Bar'),
('M7', 2, 'Bar'),
('M8', 10, 'VIP Salon');

-- Örnek kullanıcı ekleme
INSERT INTO kullanicilar (kullanici_adi, sifre, ad_soyad, rol) VALUES
('garson1', SHA2('garson123', 256), 'Ahmet Yılmaz', 'garson'),
('garson2', SHA2('garson456', 256), 'Mehmet Demir', 'garson'),
('mutfak1', SHA2('mutfak123', 256), 'Ayşe Kaya', 'mutfak'),
('mutfak2', SHA2('mutfak456', 256), 'Fatma Şahin', 'mutfak'),
('yonetici', SHA2('admin123', 256), 'Ali Veli', 'yonetici');
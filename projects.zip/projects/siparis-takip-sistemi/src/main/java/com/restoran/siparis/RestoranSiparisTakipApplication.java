package com.restoran.siparis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestoranSiparisTakipApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestoranSiparisTakipApplication.class, args);
	}

}

package com.restoran.siparis.controller;

import com.restoran.siparis.entity.Siparis;
import com.restoran.siparis.service.SiparisService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/siparisler")
public class SiparisController {

    private final SiparisService siparisService;

    public SiparisController(SiparisService siparisService) {
        this.siparisService = siparisService;
    }

    @GetMapping
    public List<Siparis> getAllSiparisler() {
        return siparisService.getAllSiparisler();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Siparis> getSiparisById(@PathVariable Long id) {
        return siparisService.getSiparisById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Siparis createSiparis(@RequestBody Siparis siparis) {
        return siparisService.saveSiparis(siparis);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Siparis> updateSiparis(@PathVariable Long id, @RequestBody Siparis siparis) {
        return siparisService.getSiparisById(id)
                .map(existingSiparis -> {
                    siparis.setId(id);
                    return ResponseEntity.ok(siparisService.saveSiparis(siparis));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSiparis(@PathVariable Long id) {
        siparisService.deleteSiparis(id);
        return ResponseEntity.noContent().build();
    }
}

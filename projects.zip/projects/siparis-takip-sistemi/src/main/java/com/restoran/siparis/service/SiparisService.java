package com.restoran.siparis.service;

import com.restoran.siparis.entity.Siparis;
import com.restoran.siparis.repository.SiparisRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SiparisService {

    private final SiparisRepository siparisRepository;

    public SiparisService(SiparisRepository siparisRepository) {
        this.siparisRepository = siparisRepository;
    }

    public List<Siparis> getAllSiparisler() {
        return siparisRepository.findAll();
    }

    public Optional<Siparis> getSiparisById(Long id) {
        return siparisRepository.findById(id);
    }

    public Siparis saveSiparis(Siparis siparis) {
        return siparisRepository.save(siparis);
    }

    public void deleteSiparis(Long id) {
        siparisRepository.deleteById(id);
    }
}
